/**
 * This package contains the Core file, which administers the window.
 */
/**
 * @author Dillon - Github dg092099
 *
 */
package dillon.gameAPI.core;