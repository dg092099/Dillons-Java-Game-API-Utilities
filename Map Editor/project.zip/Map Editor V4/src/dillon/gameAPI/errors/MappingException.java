package dillon.gameAPI.errors;

public class MappingException extends RuntimeException {

}
