/**
 * This package contains the event system, and its several events.
 */
/**
 * @author Dillon - Github dg092099
 * 
 */
package dillon.gameAPI.event;