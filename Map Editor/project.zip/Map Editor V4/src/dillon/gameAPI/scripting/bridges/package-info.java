/**
 * This package contains all of the script to API bridges.
 */
/**
 * @author Dillon
 *
 */
package dillon.gameAPI.scripting.bridges;