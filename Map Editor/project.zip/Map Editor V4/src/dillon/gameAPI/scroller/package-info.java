/**
 * This package allows a side scroller.
 */
/**
 * @author Dillon - Github dg092099
 *
 */
package dillon.gameAPI.scroller;