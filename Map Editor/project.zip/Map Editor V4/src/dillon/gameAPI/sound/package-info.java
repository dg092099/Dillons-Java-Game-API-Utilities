/**
 * This package handles the sounds in the game.
 */
/**
 * @author Dillon - Github dg092099.github.io
 * @since V1.13
 */
package dillon.gameAPI.sound;